package fp.premier;

public enum Resultado {
	A, H, D
}
